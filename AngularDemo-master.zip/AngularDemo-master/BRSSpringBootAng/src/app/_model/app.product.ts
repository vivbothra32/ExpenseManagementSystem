export class Product{
    prodId: number;
    prodName: string;
    prodCost: number;
    prodDescription:any;
}