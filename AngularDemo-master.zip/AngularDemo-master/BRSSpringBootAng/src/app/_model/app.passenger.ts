/* author Tejaswini
Created on: 19/10/2019
Last modified on: 23/10/2019
 */
export class Passenger{
    passengerId: number;
    passengerName: string;
    passengerAge: number;
    passengerGender: string;
}