/* author Mayank
Created on: 19/10/2019
Last modified on: 23/10/2019
 */
export class User{
    userId: number;
    username: string;
    pass: string;
    userType: string;
    email: string;
    phoneNumber: string;
   deleteFlag: number;

}