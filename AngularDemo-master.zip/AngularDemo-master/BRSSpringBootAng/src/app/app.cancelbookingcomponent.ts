/* author Tejaswini
description : cancel booking component
Created on: 19/10/2019
Last modified on: 23/10/2019
 */
import { Component } from '@angular/core'
import { BookingService } from './_service/app.bookingservice';

@Component({
    selector: 'cancelbooking',
    templateUrl:'../app/_html/app.viewbookings.html'
})
export class CancelBookingComponent{
    constructor(){}
}
