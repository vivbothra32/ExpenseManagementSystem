import {Component} from '@angular/core';

@Component({
    selector: 'home',
    templateUrl: './_html/app.home.html'
})

export class HomeComponent{
    
}