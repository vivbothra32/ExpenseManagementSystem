import { Component} from '@angular/core';

@Component({
    selector:'help',
    templateUrl:'../app/_html/app.aboutus.html'
})
export class HelpComponent{

}

