import {Component} from '@angular/core';

@Component({
    selector: 'error-page',
    templateUrl:'./_html/app.errorpage.html'
})

export class ErrorComponent{

}