import {Component, OnInit} from '@angular/core'

@Component({
    selector: 'aboutUs',
    templateUrl:'app.aboutus.html'
})

export class aboutUs{

}