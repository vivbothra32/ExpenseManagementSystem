

export class Product{
    prodId:number;
    prodName:String;
    prodCost:number;
}