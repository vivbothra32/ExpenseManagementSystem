import { Component} from '@angular/core';

@Component({
    selector: 'add',
    templateUrl: 'app.addemployee.html'
})

export class AddEmployeeComponent  {}