import { Component} from '@angular/core';

@Component({
    selector: 'search',
    templateUrl: 'app.searchemployee.html'
})

export class SearchEmployeeComponent  {}