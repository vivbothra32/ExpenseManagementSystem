import { Component} from '@angular/core';

@Component({
    selector: 'show',
    templateUrl: 'app.showemployee.html'
})

export class ShowEmployeeComponent  {}