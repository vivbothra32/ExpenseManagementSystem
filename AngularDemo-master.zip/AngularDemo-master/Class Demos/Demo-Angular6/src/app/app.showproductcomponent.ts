import {Component} from '@angular/core';

@Component({
    selector:'show',
    templateUrl: 'app.showproduct.html'
})

export class ShowProductComponent{ }