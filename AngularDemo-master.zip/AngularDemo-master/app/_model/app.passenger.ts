export class Passenger{
    passengerId: number;
    passengerName: string;
    passengerAge: number;
    passengerGender: string;
}