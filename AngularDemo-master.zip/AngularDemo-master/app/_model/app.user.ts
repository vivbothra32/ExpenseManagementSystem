export class User{
    userId: number;
    userName: string;
    pass: string;
    userType: string;
    email: string;
    phoneNumber: string;
   deleteFlag: number;

}