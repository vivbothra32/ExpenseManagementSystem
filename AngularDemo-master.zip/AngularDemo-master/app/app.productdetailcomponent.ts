import { Component} from '@angular/core';

@Component({
    selector:'aboutus',
    templateUrl:'app.productdetail.html'
})
export class ProductDetailComponent{

}