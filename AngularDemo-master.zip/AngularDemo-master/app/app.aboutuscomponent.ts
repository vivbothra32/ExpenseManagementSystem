import { Component} from '@angular/core';

@Component({
    selector:'aboutus',
    templateUrl:'app.aboutus.html'
})
export class AboutUsComponent{

}

