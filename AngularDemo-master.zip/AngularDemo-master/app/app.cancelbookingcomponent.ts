import { Component } from '@angular/core'
import { BookingService } from './_service/app.bookingservice';

@Component({
    selector: 'cancelbooking',
    templateUrl:'../app/_html/app.viewbookings.html'
})
export class CancelBookingComponent{
    constructor(){}
}
