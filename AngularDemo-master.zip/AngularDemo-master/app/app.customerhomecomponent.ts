import { Component} from '@angular/core'

@Component({
    selector:'customerhome',
    templateUrl: '../app/_html/app.customerhome.html'
})
export class CustomerHomeComponent{

}