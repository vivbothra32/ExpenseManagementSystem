import {Component} from '@angular/core';

@Component({
    selector: 'adminhome',
    templateUrl: './_html/app.adminhome.html'
})

export class AdminHomeComponent{}