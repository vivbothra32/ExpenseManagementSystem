import {Component} from '@angular/core';

@Component({
    selector: 'addemployee',
    templateUrl:`app.add.html`
})

export class AddEmployeeComponent{

}