import {Component} from '@angular/core';

@Component({
    selector: 'searchemp',
    templateUrl: `app.search.html`
})

export class SearchEmployeeComponent {

}