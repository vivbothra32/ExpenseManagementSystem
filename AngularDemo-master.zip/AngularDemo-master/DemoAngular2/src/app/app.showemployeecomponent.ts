import {Component} from '@angular/core';

@Component({
    selector: 'showemp',
    templateUrl:`app.show.html`
})

export class ShowEmployeeComponent {

}