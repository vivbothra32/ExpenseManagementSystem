export class Employee{
    empId : String;
    name : String;
    pan : String;
    designation : String;
    domain : String;
    dateOfJoining : any;
    dateOfBirth : any;
    salary : number;
    email : String; 
    bankName : String;
    accountNo : String;
    balance : number;
    password : String; 
    viewStatus : boolean;
}