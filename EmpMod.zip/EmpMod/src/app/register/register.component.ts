import { Component, OnInit } from '@angular/core';
import { Employee } from '../model/employee';
import { EmployeeService } from '../employee/employee.service';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {
  employee: Employee = new Employee();
  name : String = '';
  pan : String = '';
  designation : String[] = ["Analyst","Senior Analyst","Consultant","Associate Consultant","Senior Consultant","Manager","Senior Manager"];
  domain : String[] = ["Java", "DevOps", "AWS", "Angular", "SAP", "Python"];
  dateOfJoining : any = '';
  dateOfBirth : any = '';
  salary : number;

  submitted = false;

  constructor(private employeeService: EmployeeService) { }

  ngOnInit() {
  }

  newEmployee(): void {
    this.submitted = false;
    this.employee = new Employee();
  }

  save() {
    this.employeeService.createEmployee(this.employee)
      .subscribe(data => console.log(data), error => console.log(error));
    this.employee = new Employee();
  }

  onSubmit() {
    this.submitted = true;
    this.save();
  }
}
