import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';
import { Observable } from 'rxjs';
import { Employee } from '../model/employee';

@Injectable({
  providedIn: 'root'
})
export class EmployeeService {
  private baseUrl = 'http://localhost:8888/employee';
  constructor(private http: HttpClient) {
   }

   getEmployee(id: String): Observable<Object> {
    return this.http.get(`${this.baseUrl}/${id}`);
  }

  createEmployee(employee: Object): Observable<Object> {
    return this.http.post(`${this.baseUrl}`, employee);
  }

  updateEmployee(id: String, value: any): Observable<Object> {
    return this.http.put(`${this.baseUrl}/${id}`, value);
  }

  deleteEmployee(id: String): Observable<any> {
    return this.http.delete(`${this.baseUrl}/${id}`, { responseType: 'text' });
  }

  getEmployeesList(): Observable<any> {
    return this.http.get(`${this.baseUrl}`);
  }
  getEmployeeById(empId : String){
    return this.http.get<Employee>(this.baseUrl+"/id/"+empId);
  }
  getEmployeeByDomain(domain : String){
    return this.http.get<Employee>(this.baseUrl+"/domain/"+domain);
  }
  getEmployeeByDesignation(designation : String){
    return this.http.get<Employee>(this.baseUrl+"/designation/"+designation);
  }
}

