export class trainerModel{
    constructor(
    public name:String='',
    public city:String='',
    public branch:String='',
    public mobile:number=0,
    public mail:string='')
    { }
}