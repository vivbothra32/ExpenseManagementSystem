import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class EmployeeService {
  
  private baseUrl = 'http://localhost:8888/employee';
  constructor(private http: HttpClient) {
   }
  
  
  createEmployee(employee: Object): Observable<Object> {
    return this.http.post(`${this.baseUrl}`+'/add', employee);
  }
  searchDomain(domain : String):Observable<any>{
    return this.http.get(this.baseUrl+"/domain/"+domain);
  }
  searchDesignation(designation : String):Observable<any>{
    return this.http.get(this.baseUrl+"/designation/"+designation);
  }
  loginEmployee(empId : string, password : string):Observable<any>{
    let form = new FormData();
    form.append("empId",empId);
    form.append("password",password);
    return this.http.post(this.baseUrl+"/login/?empId="+empId+"&password="+password,form);
  }

  changePassword(empId: string, oldPassword: string, newPassword: string):Observable<any> {
    let form = new FormData();
    form.append("empId",empId);
    form.append("oldPassword",oldPassword);
    form.append("newPassword",newPassword);
    return this.http.post(this.baseUrl+"/password/?empId="+empId+"&oldPassword="+oldPassword+"&newPassword="+newPassword,form);
  }
}
