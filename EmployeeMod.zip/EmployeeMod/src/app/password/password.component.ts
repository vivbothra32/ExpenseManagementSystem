import { Component, OnInit } from '@angular/core';
import { EmployeeService } from '../employee.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-password',
  templateUrl: './password.component.html',
  styleUrls: ['./password.component.css']
})
export class PasswordComponent implements OnInit {
  empId : string;
  oldPassword : string;
  newPassword : string;
  employee : string
  constructor(private service : EmployeeService, private router : Router) { }

  ngOnInit() {
  }
  changePassword(){
    this.empId = sessionStorage.getItem('empId');
    this.service.changePassword(this.empId, this.oldPassword, this.newPassword).subscribe(data => this.employee, error => alert("Password could not be changed!"));
    if(this.employee != null){
      alert("Password changed successfully!");
      this.router.navigate(['search']);
    }else{
      alert("Password could not be changed!");
    }
  }
}
