import { Component, OnInit } from '@angular/core';
import { EmployeeService } from '../employee.service';
import { RouterModule, Router } from '@angular/router';
import { Observable } from 'rxjs';
import { Employee } from '../model/employee';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  empId : string;
  password : string;
  employee : Employee;
  constructor(private employeeService : EmployeeService, private router : Router) { }

  ngOnInit() {
  }
  loginEmployee(){
    this.employeeService.loginEmployee(this.empId, this.password).subscribe(data => this.employee, error => alert("Employee not logged in!"));
    sessionStorage.setItem('empId', String(this.employee.empId));
    sessionStorage.setItem('name',String(this.employee.name));
    sessionStorage.setItem('status','true');
    alert("Employee logged in successfully!");
    this.router.navigate(['search']);
  }

}
