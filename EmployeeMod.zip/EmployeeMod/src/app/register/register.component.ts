import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { EmployeeService } from '../employee.service';
import { Employee } from '../model/employee';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {
  employee: Employee = new Employee();
  empIdStatus : boolean = false;
  nameStatus : boolean = false;
  panStatus : boolean = false;
  designations : String[] = ['Analyst','Senior Analyst','Consultant','Associate Consultant','Senior Consultant','Manager','Senior Manager'];
  domains : String[] = ['Java', 'DevOps', 'AWS', 'Angular', 'SAP', 'Python'];
  dateOfJoining : any = '';
  dateOfBirth : any = '';
  designationStatus : boolean = false;
  domainStatus : boolean = false;
  salaryStatus : boolean = false;
  passwordStatus : boolean = false;
  emailStatus : boolean = false;
  emp : Employee = new Employee();
  public barLabel: string = "Password strength:";
  public myColors = ['#DD2C00', '#FF6D00', '#FFD600', '#AEEA00', '#00C853'];
  submitted = false;
  //login : LoginComponent;
  constructor(private employeeService: EmployeeService, private router: Router) {
    
   }

  ngOnInit() {
  }

  newEmployee(): void {
    this.submitted = false;
    this.employee = new Employee();
  }

  registerEmployee() {
    this.employeeService.createEmployee(this.employee)
      .subscribe(data => this.emp, error => console.log(error));
    //this.employee = new Employee();
    //this.toastr.success('Employee Added Successfully!', 'Congratulations!');
            //this.router.navigate(['/login']);
            //this.login.ngOnInit();
        if(this.emp!=null){
            alert("Employee successfully registered!");
            this.router.navigate(['login']);
        }else{
          alert("Employee could not be registered!");
          this.router.navigate(['register']);
        }
  }

  onSubmit() {
    this.submitted = true;
    this.registerEmployee();
  }

}
