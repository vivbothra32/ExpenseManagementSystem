import { Component, OnInit } from '@angular/core';
import { Observable } from 'rxjs';
import { Employee } from '../model/employee';
import { EmployeeService } from '../employee.service';

@Component({
  selector: 'app-search',
  templateUrl: './search.component.html',
  styleUrls: ['./search.component.css']
})
export class SearchComponent implements OnInit {
  employees :  Observable<Employee[]>;
  found : boolean;
  domain : String;
  designation : String;
  designations : String[] = ['Analyst','Senior Analyst','Consultant','Associate Consultant','Senior Consultant','Manager','Senior Manager'];
  domains : String[] = ['Java', 'DevOps', 'AWS', 'Angular', 'SAP', 'Python'];
  constructor(private service : EmployeeService) { }
  ngOnInit(){}
  searchEmployeebyDomain(){
    this.service.searchDomain(this.domain).subscribe(data =>this.employees = data, error => alert("Search could not be done!"));
    if(this.employees != null){
      this.found = true;
    } else{
      alert("Employee not found.")
      this.found = false;
    }
  }

  searchTrainerByBranch(){
    this.employees = this.service.searchDesignation(this.designation);
    if(this.employees != null){
      this.found = true;
    }else{
      alert("Employee not found.")
      this.found = false;
    }
  }

}
