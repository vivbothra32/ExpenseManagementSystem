import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'EmpModule';
  flag : boolean;
  ngOnInIt(){
    if(sessionStorage.getItem('status')=='true')
      this.flag = true;
    else
      this.flag = false;
  }
  logout(){
    sessionStorage.setItem('status','false');
    sessionStorage.clear();
  }
}
