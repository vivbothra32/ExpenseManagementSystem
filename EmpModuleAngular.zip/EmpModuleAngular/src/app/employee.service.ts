import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class EmployeeService {
  private baseUrl = 'http://localhost:8888/employee';
  constructor(private http: HttpClient) {
   }
  createEmployee(employee: Object): Observable<Object> {
    return this.http.post(`${this.baseUrl}`+'/add', employee);
  }
  searchDomain(domain : String):Observable<any>{
    return this.http.get(this.baseUrl+"/domain/"+domain);
  }
  searchDesignation(designation : String):Observable<any>{
    return this.http.get(this.baseUrl+"/designation/"+designation);
  }
}
