import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { EmployeeService } from '../employee.service';
import { Employee } from '../model/employee';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {
  employee: Employee = new Employee();
  empIdStatus : boolean = false;
  nameStatus : boolean = false;
  panStatus : boolean = false;
  designations : String[] = ['Analyst','Senior Analyst','Consultant','Associate Consultant','Senior Consultant','Manager','Senior Manager'];
  domains : String[] = ['Java', 'DevOps', 'AWS', 'Angular', 'SAP', 'Python'];
  dateOfJoining : any = '';
  dateOfBirth : any = '';
  designationStatus : boolean = false;
  domainStatus : boolean = false;
  salaryStatus : boolean = false;
  passwordStatus : boolean = false;
  emailStatus : boolean = false;

  submitted = false;
  //login : LoginComponent;
  constructor(private employeeService: EmployeeService, private router: Router) {
    
   }

  ngOnInit() {
  }

  newEmployee(): void {
    this.submitted = false;
    this.employee = new Employee();
  }

  resgisterEmployee() {
    this.employeeService.createEmployee(this.employee)
      .subscribe(data => console.log(data), error => console.log(error));
    this.employee = new Employee();
    //this.toastr.success('Employee Added Successfully!', 'Congratulations!');
            //this.router.navigate(['/login']);
            //this.login.ngOnInit();
            this.router.navigate(['search']);
  }

  onSubmit() {
    this.submitted = true;
    this.resgisterEmployee();
  }

}
