import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-bankdetails',
  templateUrl: './bankdetails.component.html',
  styleUrls: ['./bankdetails.component.css']
})
export class BankdetailsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
