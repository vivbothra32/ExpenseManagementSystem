import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Employee } from './model/employee';

@Injectable({
  providedIn: 'root'
})
export class EmployeeService {
  
  employee : Employee;
  private baseUrl = 'http://localhost:8888/employee';
  constructor(private http: HttpClient) {
   }
  saveEmployee(emp : Employee){
    console.log("saving employee");
    this.employee = emp;
    console.log(emp);
  }
  
  createEmployee(employee: Employee): Observable<Employee> {
    return this.http.post<Employee>(this.baseUrl+'/add', employee);
  }
  searchId(empId : String):Observable<any>{
    return this.http.get(this.baseUrl+"/id/"+empId);
  }
  searchDomain(domain : String):Observable<any>{
    return this.http.get(this.baseUrl+"/domain/"+domain);
  }
  searchDesignation(designation : String):Observable<any>{
    return this.http.get(this.baseUrl+"/designation/"+designation);
  }
  loginEmployee(empId : string, password : string):Observable<any>{
    //let form = new FormData();
    //form.append("empId",empId);
    //form.append("password",password);
    console.log("in service angular");
    return this.http.get(this.baseUrl+"/login/"+empId+"/"+password);
  }

  changePassword(empId: string, oldPassword: string, newPassword: string):Observable<any> {
    let form = new FormData();
    form.append("empId",empId);
    form.append("oldPassword",oldPassword);
    form.append("newPassword",newPassword);
    return this.http.post(this.baseUrl+"/password/?empId="+empId+"&oldPassword="+oldPassword+"&newPassword="+newPassword,form);
  }
  addBank( bankName : string, accountNo : string, salary : string):Observable<any> {
    let form=new FormData();
        form.append("empId", String(this.employee.empId));
        form.append("bankName", String(bankName));
        form.append("accountNumber", String(accountNo));
    let params = new HttpParams().set('empId',this.employee.empId).set('bankName',bankName).set('accountNo',accountNo).set('salary', salary);
      return this.http.post(this.baseUrl+'/bank?', {params});
    //return this.http.post(this.baseUrl+"/bank/"+this.employee.empId+"/"+bankName+"/"+accountNo);
  }

  deleteEmployee() {
    console.log("Logged out successfully!")
    this.employee = null;
    alert("Logged out!");
  }
}
