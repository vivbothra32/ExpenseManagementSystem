import { Component, OnInit } from '@angular/core';
import { EmployeeService } from '../employee.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-password',
  templateUrl: './password.component.html',
  styleUrls: ['./password.component.css']
})
export class PasswordComponent implements OnInit {
  empId : string;
  oldPassword : string;
  newPassword : string;
  employee : string
  constructor(private service : EmployeeService, private router : Router) { }

  ngOnInit() {
    if(sessionStorage.getItem('status')==='false'){
      this.router.navigate(['login']);
    }
    this.empId = sessionStorage.getItem('empId');
  }
  changePassword(){
    
    let emp = this.service.changePassword(this.empId, this.oldPassword, this.newPassword).subscribe(data => this.employee, error => alert("Password could not be changed!"));
    if(emp != null){
      alert("Password changed successfully!");
      this.router.navigate(['search']);
    }else{
      alert("Password could not be changed!");
      this.router.navigate(['password']);
    }
  }
}
