import { Component, OnInit } from '@angular/core';
import { EmployeeService } from '../employee.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-logout',
  templateUrl: './logout.component.html',
  styleUrls: ['./logout.component.css']
})
export class LogoutComponent implements OnInit {
  

  constructor(private employeeService : EmployeeService, private router : Router) { }

  ngOnInit() {
    this.employeeService.deleteEmployee();
    this.router.navigate(['login']);
  }

}
